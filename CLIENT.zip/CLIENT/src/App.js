import logo from './logo.svg';
// require('dotenv').config();
import './App.css';
import { GoogleLogin} from 'react-google-login';

function App() {

  const handleLogin = async googleData => {
    const res = await fetch('http://localhost:3001/api/v1/auth/google', {
        method: "POST",
        body: JSON.stringify({
        token: googleData.tokenId
      }),
      headers: {
        "Content-Type": "application/json"
      }
    })
    
    console.log( await res.json() )//.then((res)=>{console.log(res)})
    // store returned user somehow
  }


  return (
    <div className="App">
      {/* <p>{console.log(process.env.REACT_APP_GOOGLE_CLIENT_ID)}</p> */}
      <GoogleLogin
        clientId={process.env.REACT_APP_GOOGLE_CLIENT_ID}
        buttonText="Log in with Google"
        onSuccess={handleLogin}
        onFailure={handleLogin}
        cookiePolicy={'single_host_origin'}
      />
    </div>
  );
}

export default App;
