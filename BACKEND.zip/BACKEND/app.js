const express = require('express');
const path=require('path');
const cors=require('cors');
const app=express();
const bodyParser=require('body-parser');
require('dotenv').config();
// const { Pool } = require('pg');   //for postgres

const port = 3001 ;



app.use(cors())

app.use(bodyParser.json());  //to parse JSON
app.use(bodyParser.urlencoded({extended:true}));   //donot harm my code

//importing routes
// const postsRoute=require('./routes/posts');
// const userRoute=require('./routes/get');
// const deleteRoute=require('./routes/delete');
// const putRoute=require('./routes/put');

//redirect to following for specific purposes.
// app.use('/posts',postsRoute);
// app.use('/get',userRoute);    

// app.use('/delete',deleteRoute);
// app.use('/put',putRoute);



app.get('/',(req,res)=>{
    res.json({"asdasd":"asdasd"})
})


const { OAuth2Client } = require('google-auth-library')
const client = new OAuth2Client(process.env.CLIENT_ID)

app.post("/api/v1/auth/google", async (req, res) => {
    const { token }  = req.body
    const ticket = await client.verifyIdToken({
        idToken: token,
        audience: process.env.CLIENT_ID
    });
    const { name, email, picture } = ticket.getPayload();    
    // const user = await db.user.upsert({ 
    //     where: { email: email },
    //     update: { name, picture },
    //     create: { name, email, picture }
    // })
    const user={
        "Name":name,
        "email":email,
        "picture":picture
    }
    console.log("asdasdasdasd")

    res.status(201)
    res.json(user)
})



app.listen(port);








